from fastapi import FastAPI, Query
from .queue.connection import queue  # ✅ import the queue, not the connection
from .queue.worker import process_query

app = FastAPI()

@app.get("/")
def chat():
    return {"status": "Server is up and running"}

@app.post("/chat")
def chat(query: str = Query(..., description="chat messages")):
    job = queue.enqueue(process_query, query)
    return {"status": "queued", "job_id": job.id}
