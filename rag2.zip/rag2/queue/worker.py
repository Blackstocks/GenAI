async def process_query(query: str):
    print("User Query", query)