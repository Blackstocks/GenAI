import os
from pathlib import Path

from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_qdrant import QdrantVectorStore

api_key = "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"

if not api_key:
    raise ValueError("❌ OPENAI_API_KEY not set!")

print(f"✅ API key loaded: {api_key[:20]}...")

# Load PDF
pdf_path = Path(__file__).parent / "rag2.pdf"
print(f"Loading PDF from: {pdf_path}")

if not pdf_path.exists():
    raise FileNotFoundError(f"❌ PDF file not found: {pdf_path}")

loader = PyPDFLoader(file_path=str(pdf_path))
docs = loader.load()
print(f"✅ Loaded {len(docs)} pages from PDF")

# Chunk text
text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
split_docs = text_splitter.split_documents(docs)
print(f"✅ Split into {len(split_docs)} chunks")

# Embeddings
embedding_model = OpenAIEmbeddings(
    model="text-embedding-3-large",
    openai_api_key=api_key
)
print("✅ Created embedding model")

# Qdrant Vector Store
vector_store = QdrantVectorStore.from_documents(
    documents=split_docs,
    url="http://localhost:6333",
    collection_name="tutorial",
    embedding=embedding_model
)
print("✅ Document indexing complete.")


